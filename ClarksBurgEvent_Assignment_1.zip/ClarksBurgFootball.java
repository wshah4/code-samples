/*
Wajaat Shah
09/22/2019
IT-206-201
Assignment 2

Description:
   -This program is designed for a high school fooball team in order to help them keep track of information regarding
   tickets for events. This program operates with user input and carries out various tasks.
   -The user is asked for the name of the event, what the maximum number of seats available are, whether or not the event
   is sponsered, the number of adult tickets sold, the number of childrens tickets sold and the number of 
   free tickets sold.
      -The user inputs a name and capacity for a given event.
      -When the user input indicates that an event is sponsored the program will calculate the total amount of donation
       being recieved on adult and child tickets.
      -Upon users entering the number of adult and child tickets the program will calculate a revenue amount.
       The revenue is based on adults tickets = $7 and child tickets = $4.
      -The user is then propted with the chance to continue adding more tickets or to quit. The program then outputs
       a report with all the information input and all calculations.
*/

import javax.swing.*;

public class ClarksBurgFootball{
   
   //Declaring variable "event" as the class type event, and setting static class variables used through out methods in this class
   static ClarksBurgEvent event;
   static boolean check;
   static int adultCounter;
   static int childCounter;
   static int freeCounter;
   static int totalCounter;
         
public static void main( String [] args){     
   
   //Instantiating an object of the implementation class and calling methods to carry out there task, lastly printing out report
   event = new ClarksBurgEvent();     
   ClarksBurgFootball rf = new ClarksBurgFootball();
   rf.eventNameMethod();
   rf.capacityMethod();
   rf.eventTypeMethod();
   rf.numAdultMethod();
   rf.numChildMethod();
   rf.numFreeMethod();
   rf.flagMethod();
   JOptionPane.showMessageDialog(null, event.toString());
   }

/*
   this method when called prompts the user with an input request for the name of the event, it takes the name
   and uses an accesor from the event class to set the eventName vriable. It also calls a error validation method
   which loops the user through until valid input requirment is met.
*/  
public String eventNameMethod(){
   //this line of code will call the eventName mutator in order to set its valuenthrough user input
   event.setEventName(JOptionPane.showInputDialog("Please enter the event name."));
   //this line of code will call a method in order to validate user input
   checkStringMethod(event.getEventName());
   if(check == true){
      eventNameMethod();
   }
   return event.getEventName();
   }

/*
   This method prompts user to input he maximum number of seats avaiable for sale, while also using the
   event class mutator to set the value for a given instance. It also calls a validation method in order
   to only get valid inputs, and if not carries a loop until requirments are met.
*/
public int capacityMethod() {
   //taking in user input by calling the mutator in the definition class
   try{
   event.setCapacity(Integer.parseInt(JOptionPane.showInputDialog("Enter maximum number of seats.")));
   }catch (NumberFormatException e){
   event.setCapacity(0);
   }
   //validating user input by calling a method
   checkNumberMethod(event.getCapacity());
   if(check == true){
   capacityMethod();
   }
   return  event.getCapacity();
   }

/*
   This method prompts the user for sponsership options and using the mutator for the eventType sets its value in the event class.
   The method also calls validations for inputs, while looping over and over until proper input is entered.
*/
public String eventTypeMethod(){
   //this line of code when executed calls the event class mutator in order to set the event as sponsered or not.
   event.setEventType(JOptionPane.showInputDialog("Is this event sponsored? Enter 'Y' for yes or 'N' for no."));
   if(!(event.getEventType().equalsIgnoreCase("Y")) && !(event.getEventType().equalsIgnoreCase("N"))){
   event.setEventType("");
   }
   //this line of code calls the checkStringMethod in order to validate the input and prompt to try again if wrong input is passed
   checkStringMethod(event.getEventType());
   if(check == true){
   eventTypeMethod();
   }   
   return event.getEventType();  
   }
   
/*
   This method prompts user for the number of adult tickets sold,
   while also validating the user input by calling a validation method.
   A counter is also being incremented in this method in order to keep track of tickets sold on first time,
   and to add new values every time program loops in order to have total number of tickets sold after all loops are done.
*/      
public int numAdultMethod(){
      //this line of code will take user input and set the number of adult tickets sold by calling its mutator
      try{
      event.setNumAdult(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of adult tickets sold")));
      } catch (NumberFormatException e){
      event.setNumAdult(0);
      }
      //this line of code calls the checkStringMethod in order to validate the input and prompt to try again if wrong input is passed
      checkTickets(event.getNumAdult());
      if(check == true){
      numAdultMethod();
      }
      adultCounter += event.getNumAdult();
      return event.getNumAdult();
   }
  

/*
   Just like the numAdultMethod() this method takes user input for
   the number of children tickets sold, validates by calling a validation method,
   adds the old and new input value together to set a new value each time the program loops.
*/
public int numChildMethod(){
      //this line of code will call the mutator for numChild in the definition calss
      try{
      event.setNumChild(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of child tickets sold")));
      } catch (NumberFormatException e){
      event.setNumChild(0);
      }
      //calling the validation method for user input
      checkTickets(event.getNumChild());
      if(check == true){
      numChildMethod();
      }
      childCounter += event.getNumChild();
      return event.getNumChild();
   }

/*
   This also does the same event as numAdultMethod() and numChildMethod() where it takes in user input for number of free tickets sold,
   validates it by calling a validation methof, and changes old value by adding it to the new value each time program
   loops.
*/
public int numFreeMethod(){
      //taking in user input to set the value of numFree variable by callig its mutator in the event class
      try{
      event.setNumFree(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of Free tickets sold")));
      } catch (NumberFormatException e){
      event.setNumFree(0);
      }
      //validating the user input by calling a validation method
      checkTickets(event.getNumAdult());
      if(check == true){
      numFreeMethod();
      }
      freeCounter += event.getNumFree();
      return event.getNumFree();
   }

/*
   This method when called prompts the user to set the value of a flag variable in the event class. This method then depending
   on the users input for the flag variable will loop the user through once more to enter the number of tickets sold and appear 
   again at the end again in order to repeat program if wanted or to quit.
*/
public void flagMethod(){
   totalCounter = adultCounter + childCounter + freeCounter;
   try{
   event.setFlag(Integer.parseInt(JOptionPane.showInputDialog("Enter 1 to continue, enter 0 to quite")));
   } catch (NumberFormatException e){
      event.setFlag(-1);
   }
   while (!(event.getFlag() == 1) && !(event.getFlag() == 0)){
   JOptionPane.showMessageDialog(null, "Invalid Entry try again");
   event.setFlag(Integer.parseInt(JOptionPane.showInputDialog("Enter 1 to continue, enter 0 to quite")));
   }
    
   //when the user decides to set the flag variable as continue, this block of code will execute
   //the methods which prompt the user for the number of adult, child, and free tickets.
   //it then adds the user input value and the previous value, and sets the total as the value of each variable in the event class
   while(event.getFlag() == 1 ){ 
      if(totalCounter < event.getCapacity())
         {  event.setNumAdult(adultCounter + numAdultMethod());   }
      if(totalCounter < event.getCapacity())
         {  event.setNumChild(childCounter + numChildMethod());   }
      if(totalCounter < event.getCapacity())
         {  event.setNumFree(freeCounter + numFreeMethod());   }
      if(totalCounter< event.getCapacity())
         {  flagMethod();  }
      else {
      JOptionPane.showMessageDialog(null, "Max Seats Reached");
      flagMethod();
      }
   }
       
}
//This method is used to validate user inputs and prompt them with an error message when violated, it returns a boolean value for check
//variable, which is used to loop the user through validation until requirements are met
public boolean checkStringMethod(String input){
   if(input==null || input.equals("")){
   JOptionPane.showMessageDialog(null, "Inavlid entry try again");
   check = true;
   }else{
   check = false;
   }
   return check;
   }

//this method provides error checking for user input of integers and returns a boolean required for loops used in methods
public boolean checkNumberMethod(int number){
   if(number <=0 || number > 5000){
   JOptionPane.showMessageDialog(null, "Invalid entry");
   check = true;
   }else{
   check=false;
   }
   return false;   
   }

//this method provides validation for user input of number of tickets. It checks to make sure no values 
//entered are negatives and that the total number entered does not exceed the max =imum number of seats.
public boolean checkTickets(int tickets){
   if(tickets < 0 ){
      JOptionPane.showMessageDialog(null, "Invalid entry made try again");
      check = true;
      return check;
   } else if(event.getTotalTickets() > event.getCapacity()){
      JOptionPane.showMessageDialog(null, "Seats exceed max capacity");
      check = true;
      return check;
   } else{
   check = false;
   }
   return check;
   }

}//class end