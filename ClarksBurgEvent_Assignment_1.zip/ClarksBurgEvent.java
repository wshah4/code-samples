//this body of code is a data defintion clas when object instances are created this class is used to
//populate and access data of a specific instance
import javax.swing.*;
public class ClarksBurgEvent{
   private String eventName;
   private int capacity = 5000;
   private String eventType;//if true, then sponsered;
   private static int numAdult;
   private static int numChild;
   private static int numFree;
   private int donation;
   private int totalTickets;
   private int totalRevenue;
   private String report;
   private int flag;
   
   /*
   The following line of code are accessors (ie. get methods) used to access values outside this class
   and mutators  (ie. set methods) which set values of variable for object instances of this class.
   */

    public String getEventName(){
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public int getNumAdult() {
        return numAdult;
    }

    public void setNumAdult(int numAdult) {
        this.numAdult = numAdult;
    }

    public int getNumChild() {
        return numChild;
    }

    public void setNumChild(int numChild) {
        this.numChild = numChild;
    }

    public int getNumFree() {
        return numFree;
    }

    public void setNumFree(int numFree) {
        this.numFree = numFree;
    }

    public int getDonation() {
        return donation;
    }

    public void setDonation(int donation) {
        this.donation = calcDonation();
    }

    public int getTotalTickets() {
        return totalTickets;
    }

    public void setTotalTickets() {
        this.totalTickets = calcTotalTickets();
    }

    public int getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue() {
        this.totalRevenue = calcTotalRevenue();
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }
    
//This method calculates the total number of tickets sold and returns its value
private int calcTotalTickets(){
   int totalTickets = (this.getNumAdult() + this.getNumChild() + this.getNumFree());
   return totalTickets;
   }

//This method calcualtes the total revenue and when the program loops and new values are entered it is designed to increment
//the revenue accordingly.     
private int calcTotalRevenue(){
   int rev = this.getTotalRevenue();
   rev+= (this.getNumAdult() * 7) + (this.getNumChild() * 4);
   return rev;
  }

//This method is called when users indicate an event is sponsered, it calculates the total amount of donation, sets its value,
//and returns the amount.
private int calcDonation(){
   if(this.getEventType().equalsIgnoreCase("Y")){
   donation = ((this.getNumAdult() + this.getNumChild()) * 1);
   }
   return donation;
   }

//this is a public method called outside of this class in order to print a string report
public String toString(){
      String report = "Event Name:                    "+getEventName()+"\n"+
                     "Max number of seats:       "+getCapacity()+"\n"+
                     "Adult tickets Sold:             "+getNumAdult()+"\n"+
                     "Child tickets sold:             "+getNumChild()+"\n"+
                     "Free tickets sold:              "+getNumFree()+"\n"+
                     "Total tickets:                      "+calcTotalTickets()+"\n"+
                     "Total Revenue:                $ "+calcTotalRevenue()+"\n"+
                     "Sponsor donation:             $ "+calcDonation();
                     return report;
   }
   
}
   