/*
this java file is used to instantiate instances of FileServer class, it holds methods to
access/populate FileServer instance variables. This class inherits methods from its parent class
Customer.
*/
public class FileServer extends Customer implements VM{

//variables
   private String storageType;
   private String storageMedia;
   private int memory;
   private double rate;
   private int diskSpace;
   
   FileServer(){
      this.diskSpace = 0;
      this.memory = startMemory;
   }
   
//getters
   public String getStorageType(){return storageType;}
   public String getStorageMedia(){return storageMedia;}
   public int getMemory(){return memory;}
   public int getDiskSpace(){return diskSpace;}   
   
   public double getRate(){
   //here the rate will be set according to the storage type a customer has
   // and also if they have a discount
      if(this.getStorageMedia().equals("SSD")){
         if(super.getDiscount()){
            this.rate = (startRate + (this.memory * 5)) * .80 ;
         }else{
            this.rate = (startRate + (this.memory * 5));
         }
      }else{
         if(super.getDiscount()){
            this.rate = (startRate + (this.diskSpace * 2)) * .80 ;
         }else{
            this.rate = (startRate + (this.diskSpace * 2));
         }
       
      }
      return this.rate;
   }
   
//setters
   public void setStorageType(int storageType){
      if(storageType == 1){
         this.storageType = "Block";
      }else if(storageType == 2){
         this.storageType = "Object";
      }else{
         throw new IllegalArgumentException("Storage type selection invalid");
      }
   }
   
   public void setStorageMedia(int storageMedia){
      if(storageMedia == 1){
         this.storageMedia = "SSD";
      }else if(storageMedia == 2){
         this.storageMedia = "Magnetic";
      }else{
         throw new IllegalArgumentException("Storage Media selection invalid");
      }
   }
   
   public void setMemory(int memory){
      if(memory < 0 ){
         throw new IllegalArgumentException("memory amount can not be 0 ");
      }else if(memory > 1024){
         throw new IllegalArgumentException("memory amount can not exceed 1024 terabytes");
      }else{
         this.memory = memory;
      }
   }
   
   public void setDiskSpace(int diskSpace){
      if(diskSpace < 0 ){
         throw new IllegalArgumentException("Disk Space amount can not be 0 ");
      }else if(diskSpace > 1024){
         throw new IllegalArgumentException("Disk Space can not exceed 1024 terabytes");
      }else{
         this.diskSpace = diskSpace;
      }
   }
   

//toString
   public String toString(){
      String report = super.toString();
      report = report + "\n" +
               "Memory Used : TB" + getMemory() +
               "\nDisk Space Used : TB" + getDiskSpace() +
               "\nStorage Type : " + getStorageType() +
               "\nStorage Media : " + getStorageMedia() +
               "\nMonthly Rate : $" + getRate();
      return report;
   }

}