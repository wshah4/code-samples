/*
this java file is used to instantiate instances of Customer class, it holds methods to
access/populate Customer instance variables. This class is inherited by its subclasses
which allows them to inherit its methods.
*/

public class Customer{

// variables
   private String name;
   private String phone;
   private String email;
   private boolean discount;
   private String id;
   private double rate;

//cunstructor
   Customer(){
   
   }
   
// getters
   public String getName(){return this.name;}
   public String getPhone(){return this.phone;}
   public String getEmail(){return this.email;}
   public boolean getDiscount(){return this.discount;}
   public String getId(){return this.id;}
   public double getRate(){return this.rate;}
   
// setters
   public void setName(String name){
      if(name.trim().length() < 1){
         throw new IllegalArgumentException("name can not be empty");
      }else{
         this.name = name;
      }
   }

//this method will take in the user input of a phone number and provide validation
//in order for it to meet the phone number requirments
   public void setPhone(String phone){
      String example = "(571)123-3456";
      String message = "phone number must be in following format : " + example;
      char a = '(';
      char b = ')';
      char d = '-';
         
         if((phone == null) || phone.length() < 1){
             throw new IllegalArgumentException("Phone number can not be empty");
         }else{
            //here the progrm will validate that the email meets the reuirements for '(' and ')'
            for(int i = 0; i < example.length(); i++){
               if(i == 0){
                char c = phone.charAt(i);
                  if(!(a == c)){
                     throw new IllegalArgumentException(message);
                  }
               }else if( i == 4){
                   char c = phone.charAt(i);
                     if(!(b == c)){
                        throw new IllegalArgumentException(message);
                     }
               //here the program will validate that the '-' is in the right format
               }else if(i == 8){
                   char c = phone.charAt(i);
                     if(!(d == c)){
                        throw new IllegalArgumentException(message);
                     }
               //here the program will ensure all characters that are not '(', ')', or '-' are digits
               }else if(!(i == 0) && !(i == 4) && !(i == 8)){
                  if(!(Character.isDigit(phone.charAt(i)))){
                     throw new IllegalArgumentException(message);
                  }
               }
            }
         }
      this.phone = phone;
   }
   
   public void setEmail(String eAdd){
      String email = eAdd.trim();
      int atCounter = 0;
      int atIndex = 0;
      int periodCounter = 0;
      int periodIndex = 0;
      char d = '@';
      char p = '.';
      char u = '_';
      
      if(email.length()<1){
         throw new IllegalArgumentException("Email can not be empty");
      }else{
         //here the program will count the number of @ and periods in the email address
         for(int i = 0; i < email.length(); i++){
            char c = email.charAt(i);
            //here the program will validate the first letter of the email is a letter or digit
            if(i == 0 && !(Character.isLetter(c) || (Character.isDigit(c)))){
               throw new IllegalArgumentException("First character of email must be a letter or a digit");
            }else if(c == d){
               atCounter++;
               atIndex = i;
            }else if(c == p){
               periodIndex = i;
               periodCounter ++;
            } 
         }
         
         if(atCounter == 0 || periodCounter == 0){
            throw new IllegalArgumentException("There has to be one period and one @ symbol in the email address");
         }else if(atIndex > periodIndex){
            throw new IllegalArgumentException("there can not be a period before the @ symbol in the email address");
         }else if((atCounter > 1) || (periodCounter > 1)){
            throw new IllegalArgumentException("There can only be 1 period and 1 @ symbol in the email address");
         //validate that the @ and period are not next to each other
         }else if((atIndex + 1) == periodIndex){
            throw new IllegalArgumentException("There must be a letter or digit between the @ symbol and period");
         }else{
         //validate that there is at least one or more between the @ and period
            String e1 = email.substring((atIndex + 1), periodIndex);
            for(int i = 0; i < e1.length(); i++){
               if(!(Character.isLetter(e1.charAt(i))) && !(Character.isDigit(e1.charAt(i))) ){
                  throw new IllegalArgumentException("There must be a letter or digit between the @ symbol and period");
               }
            }
         }
   
         //validate that there is at least one or more letter/digit after the period
         String e2 = email.substring((periodIndex +1));
            int letterCounter = 0;
            if(e2.length() < 1){
               throw new IllegalArgumentException("There must be at least one letter or digit after the period");
            }else{
               for(int i = 0; i < e2.length(); i++){
                  if(!(Character.isLetter(e2.charAt(i))) && !(Character.isDigit(e2.charAt(i))) ){
                     throw new IllegalArgumentException("There must be a letter or digit after the period");
                  }
               }
            }
         this.email = email;
         }
      
   }
    public void setDiscount(int discount){
      if(discount == 1){
         this.discount = true;
      }else if(discount == 2){
         this.discount = false;
      }else{
         throw new IllegalArgumentException("Selction made is invalid");
      }
   }
   
   public void setId(String id){
      this.id = id;
   }
   
   public String toString(){
      String report = " ";
      report = "Customer ID: " + getId()+
               "\nName : " + getName() +
               "\nPhone : " + getPhone() +
               "\nEmail : " + getEmail() +
               "\nRecieved Dicount : " + getDiscount();
      return report;
   }
}