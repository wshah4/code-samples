/*
Wajaat Shah
IT-206-001
12/1/2019
Programming Assignment 10

This program is designed to help a cloud computing company manage the data it has on it's various customers.
The company leases server space to individuals and charges them a monthly fee. The Program is designed to help
it's user take user input for the type of server a customer requires. The user must input the following for all
customers:
-customer name
-phone number
-email address
-if they recieve a discount
it will then automatically assign them a customer id number.

The program will then require user to input the following
-if a webserver is needed the user is asked for the amount of additional memory required
-if a file server is needed then user must choose a type of storage, storage media, and amount needed.
-if a bitcoin server is need the user must choose the number of GPU's and their brand.

The program will continue adding customers until the maximum limit is met or if the user indicates they are done.
Upon completion of entering customers the program will print a report with all customer detail, a statistic
report populated with requested data, and a text file will be created to allow email sharing of the customer roster.
*/


import javax.swing.*;
import java.io.*;

public class SummaryImpl{
//class varaibles
public static boolean flag;
public static int idCounter = 1000;
public static int customerCounter = 0;
public static final int MAX_CUSTOMERS = 1000;
public static Customer newCustomer;
public static Customer[] customerArray = new Customer[2];

//main
   public static void main(String [] args){
   
   //here the program will call the getFunction method to 
      int go = 1;
      do{
         go = getFunction();
      }while(go == 1);
      
      try{
         JOptionPane.showMessageDialog(null, printFile());
      }catch(FileNotFoundException f){
         JOptionPane.showMessageDialog(null, "File was not created properly");
      }
   }
   
//function will carryout if the maximum number of customers are not met, or if user indicates they
// want to quit, the method will prompt the user for an option to either call a method to create a customer or see a report
   public static int getFunction(){
      flag = false;
      int function = 0;
      do{
         try{
            function = Integer.parseInt(JOptionPane.showInputDialog("Select Function: \n1) Add a Customer \n2) Quit"));
            flag = true;
               if(!(function == 1) && !(function ==2)){
                  JOptionPane.showMessageDialog(null, "Invalid selection made, try again");
                  flag = false;
               }
         }catch(NumberFormatException n){
            JOptionPane.showMessageDialog(null, "Invalid selection made, try again");
            flag = false;
         }
      }while(flag == false);
      
      //the program will call the proper methods according to the function variable input
      if(function == 1 && customerCounter < customerArray.length){
         //method called to create/populate a customer instance
         makeEntry();
      }else if(function == 2){
         //method called to see summary of customer details and a statistics report
         getReport();
         getSummaryReport();
      }else{
         JOptionPane.showMessageDialog(null, "Maximum number of Customers met, can not add more");
      }
      
      return function;
   }
   
//this method will carry out the necessary methods to create an instance which will populate the customer array
   public static void makeEntry(){
   
   //type of server selection
      int serverType = 0;
      //here the program gets user inputs the type of server they want by selecting the type of server from the menu
      flag = false;
      do{
         try{
            serverType = Integer.parseInt(JOptionPane.showInputDialog("Please enter a number for Server Type Selection:\n 1) WebServer\n 2) FileServer\n 3) BitcoinServer"));
            flag = true;
         }catch(NumberFormatException n){
            JOptionPane.showMessageDialog(null, "Enter a number for selection");
            flag = false;
         }
      }while(flag == false);
      
      //here the program is down casting and populating the Customer instance to a server instance, also populating server instance variables with user input data,
      //it will also populate the instance by calling additional methods.
      switch(serverType){
      case 1:
         newCustomer = new WebServer();
         addCustomer();
         addWebServer();
         break;
      case 2:
         newCustomer = new FileServer();   
         addCustomer();
         addFileServer();  
         break;    
      case 3:
         newCustomer = new BitcoinServer();
         addCustomer();
         addBitcoinServer();
         break;
         
      default:
      }
   }
   
   //this method when called will populate the variables in the Customer class instances
   public static void addCustomer(){
   //here the program will prompt, read, and validate the user input for Customer name
   //it will then use it to populate the instance variable 
      flag = false;
      do{
         try{
            newCustomer.setName(JOptionPane.showInputDialog("Enter Customer Name"));
            flag = true;
         }catch(IllegalArgumentException i){
            JOptionPane.showMessageDialog(null, i.getMessage());
            flag = false;
         }
      }while(flag == false);
   
   //here the program will prompt, read, and validate the user input for customer phone number
   //it will then use it to populate the instance variable 
      flag = false;
      do{
         try{
            newCustomer.setPhone(JOptionPane.showInputDialog("Enter Customer Phone Number"));
            flag = true;
         }catch(IllegalArgumentException i){
            JOptionPane.showMessageDialog(null, i.getMessage());
            flag = false;
         }
      }while(flag == false);
      
   //here the program will prompt, read, and validate the user input for email address
   //it will then use it to populate the instance variable 
      flag = false;
      do{
         try{
            newCustomer.setEmail(JOptionPane.showInputDialog("Enter the Customers Email address"));
            flag = true;
         }catch(IllegalArgumentException i){
            JOptionPane.showMessageDialog(null, i.getMessage());
            flag = false;
         }
      }while(flag == false);
      
   //here the program will prompt, read, and validate the user input for if a customer has a corporate discount
   //it will then use it to populate the instance variable 
      flag = false;
         do{
            try{
               newCustomer.setDiscount(Integer.parseInt(JOptionPane.showInputDialog("Make a selection if Customer recieves Discount :\n1) Yes \n2) No")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);
      
   //here the program will auto-assign the user with an id
      flag = false;
      do{
         newCustomer.setId("Cus" + idCounter);
         idCounter ++;
         flag = true;
      }while(flag == false);
   
      
   }//addCustomer end
   
   //this method when called will cast the above created/populated customer instance into a webserver instance
   //in order to populate the downcasted instance variables
   public static void addWebServer(){
         WebServer newWebServer = (WebServer) newCustomer;  
         //here the program will prompt, read, and validate user input for the amount of memory required
         // and store its value in the instance variable 
            flag = false;
            do{
               try{
                  newWebServer.setMemory(Integer.parseInt(JOptionPane.showInputDialog("Enter the additional memory required for server")));
                  flag = true;
               }catch(NumberFormatException n){
                  JOptionPane.showMessageDialog(null, "Please enter a number for amount of memory");
                  flag = false;
               }catch(IllegalArgumentException i){
                  JOptionPane.showMessageDialog(null, i.getMessage());
                  flag = false;
               }
            }while(flag == false);
         
         //here the program will fill the customer array with the newWebServer object and increment the number of objects in the array currentlty
            customerArray[customerCounter] = newWebServer;
            customerCounter ++;
   }

   //this method when called will cast the above created/populated customer instance into a file server instance
   //in order to populate the downcasted instance variables
   public static void addFileServer(){
      FileServer newFileServer = (FileServer) newCustomer;
      //here the program will prompt, read and validate the user input for the type of storage needed
      //it will store the value in the instance variable
      flag = false;
         do{
            try{
               newFileServer.setStorageType(Integer.parseInt(JOptionPane.showInputDialog("Enter Storage Type:\n1) Block \n2) Object")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);
      
      //here the program will prompt, read and validate the user input for the type of storage media needed
      //it will store the value in the instance variable
      flag = false;
         do{
            try{
               newFileServer.setStorageMedia(Integer.parseInt(JOptionPane.showInputDialog("Enter Storage Media Type:\n1) SSD \n2) Magnetic")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);
      
      //here the program will prompt, read and validate the user input for the amount of storage needed
      //it will take in use input for memeor if they need SSD storage
      if(newFileServer.getStorageMedia().equals("SSD")){
         flag = false;
         do{
            try{
               newFileServer.setMemory(Integer.parseInt(JOptionPane.showInputDialog("Enter Required Memory Amount in terabytes")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);   

      }else{
      
      //here the program will take in diskspace amount required if the user requested magnetic disk storage
      //it will validate input and store the value in the instace variable
         flag = false;
         do{
            try{
               newFileServer.setDiskSpace(Integer.parseInt(JOptionPane.showInputDialog("Enter Required Disk Space Amount in terabytes")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);   

      }
            
      //add fileserver into customer array and increment the number of onjects in the array
         customerArray[customerCounter] = newFileServer;
         customerCounter ++;
      
      }

   //this method when called willm populate the instance variables of a bitcoin server instance
   public static void addBitcoinServer(){
   //cast new customer to a bitcoinserver
      BitcoinServer newBitcoinServer = (BitcoinServer) newCustomer;
      //here the program will prompt, read and validate the user input for the number of GPU's required
      //and store its value in the instance variable
         flag = false;
         do{
            try{
               newBitcoinServer.setNumGpu(Integer.parseInt(JOptionPane.showInputDialog("Enter Number of GPU's required")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);
    
      //here the program will prompt, read, and validate the users input for the brand of GPU
      // and store its value in the instance variable
         flag = false;
         do{
            try{
               newBitcoinServer.setBrand(Integer.parseInt(JOptionPane.showInputDialog("Select GPU Brand :\n1) AMD \n2) Nvidia")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, "Invalid entry, please enter a number");
               flag = false;
            }catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null, i.getMessage());
               flag = false;
            }
         }while(flag == false);
       
      //adding the Bitcoin server into customer array and incrementing the array
         customerArray[customerCounter] = newBitcoinServer;
         customerCounter ++;
    }
    
   public static void getReport(){
   //here the program will create a report for each customer and calculate all the monthly fees incured as a total
   // it will also calculate the amount incured with discounts used
      double total = 0;
      double discountTotal = 0;
      String report = "";
      for(int i = 0; i < customerArray.length && !(customerArray[i] == null); i++){
         report = report + "\n" + customerArray[i] + "\n********************";
         total = total + customerArray[i].getRate();
            if(customerArray[i].getDiscount()){
               discountTotal = discountTotal + customerArray[i].getRate();
            }
      }
      report = report + "\n" + "Total Monthly Fees : $" + total + "\n" + 
               "Total Monthly Fees with Discount : $" + discountTotal;
      JOptionPane.showMessageDialog(null, report);
   }
   
   //when called this method will create a statistics report with data collected from instances with the Customer Array
   public static void getSummaryReport(){
   //variable decleration
      String report = "";
      int numVM = 0;
      double totalMonthly = 0;
      int totalMemory = 0;
      int diskSpace = 0;
      int numGpu = 0;
      int miners = 0;
      
      //here the program will go through the array of Customers an downcast the instance according to its instance type,
      //in order to be able to use functions within specific Class types
      for(int i = 0; i < customerArray.length && !(customerArray[i] == null); i++){
         totalMonthly = totalMonthly + customerArray[i].getRate();
            if(customerArray[i] instanceof WebServer){
               WebServer newWeb = (WebServer) customerArray[i];
               totalMemory = totalMemory + newWeb.getMemory();
            }else if (customerArray[i] instanceof FileServer){
               FileServer newFile = (FileServer) customerArray[i];
               totalMemory = totalMemory + newFile.getMemory();
               diskSpace = diskSpace + newFile.getDiskSpace();
            }else{
               BitcoinServer newBitcoin = (BitcoinServer) customerArray[i];
               numGpu = numGpu + newBitcoin.getNumGpu();
               miners++;
            }
         numVM++;
      }
      double avgTotal = totalMonthly / numVM;
      
      //here the program is creating a report with variables collected above
      report = "Number of VM's used : " + numVM + "\n" +
               "Total monthly fees collected : $ " + totalMonthly + "\n" +
               "Average monthly fee per Customer : $ " + avgTotal + "\n" +
               "Total memory used : " + totalMemory + "\n" +
               "Total DiskSpace used : TB " + diskSpace + "\n" +
               "Number of GPU's used : " + numGpu + "\n" +
               "Number of bitcoin miners : " + miners;
   
      JOptionPane.showMessageDialog(null, report);
   }
   
   //this method when called will go thorugh the customer array to gather the customer name and id in order to make a report,
   //it will also create a text file for emailing purposes
   public static String printFile() throws FileNotFoundException {
      //a printwriter object created to start a text file and send Strings into it
         PrintWriter out = new PrintWriter(new FileOutputStream(new File("customer_roster.txt")));
         out.println("******** Summary Report ********");
         out.println("Customer_Name       Customer_id");
         int numCustomers = 0;
         String report = "******** Summary Report ******** \nCustomer_Name       Customer_id";
         
         //going through the customer array and gatherin customer names and id's
         for(int i = 0; i < customerArray.length && !(customerArray[i] == null); i++){
            out.println(customerArray[i].getName() +"                  "+ customerArray[i].getId());
            report = report + "\n" + (customerArray[i].getName() +"                         "+ customerArray[i].getId()) + "\n";
            numCustomers ++;
         }
         out.println("Total number of customers :  " + numCustomers );  
         report = report + " Total Number customers : " + numCustomers;
         out.close();  
      return report;   
   }

   
}
