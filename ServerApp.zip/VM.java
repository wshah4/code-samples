/*
This java file serves as an interface which can be implemeted by other java classes.
Classes which have implemted this interface will have access to the constants listed
below.
*/
public interface VM{

// Constants
   public final double startRate = 20;
   public final int startMemory = 8;
   public final int startStorage = 20;
}