/*
this java file is used to instantiate instances of BitcoinServer class, it holds methods to
access/populate BitcoinServer instance variables. This class inherits methods from its parent class
Customer.
*/
public class BitcoinServer extends Customer implements VM{

//variables
   private int numGpu;
   private String brand;
   private double rate;
   
//getters
   public int getNumGpu(){return numGpu;}
   public String getBrand(){return brand;}
   
   public double getRate(){
   //this method sets the rate according to the type of GPU brand
   // and whether a customer has a discount or not
      if(this.getBrand().equals("AMD")){
         if(super.getDiscount()){
            this.rate = (startRate + (this.numGpu * 10)) * .80 ;
         }else{
            this.rate = (startRate + (this.numGpu * 10));
         }
      }else{
         if(super.getDiscount()){
            this.rate = (startRate + (this.numGpu * 15)) * .80 ;
         }else{
            this.rate = (startRate + (this.numGpu * 15));
         }
       
      }
      return this.rate;

   }
   
//setters
   public void setNumGpu(int numGpu){
      if(numGpu < 1){
         throw new IllegalArgumentException("Number Gpu can not be zero");
      }else if(numGpu > 8){
         throw new IllegalArgumentException("Number Gpu can not be more than 8");     
      }else{
         this.numGpu = numGpu;
      }
   }
   
   public void setBrand(int input){
      if(input == 1){
         this.brand = "AMD";
      }else if(input == 2){
         this.brand = "Nvidia";
      }else{
         throw new IllegalArgumentException("Invalid Entry made");
      }
   }

//toString
   public String toString(){
      String report = super.toString();
      report = report + "\n" +
               "Number of GPU's : " + getNumGpu() +
               "\nGpu Brand : " + getBrand() +
               "\nMonthly Rate : $" + getRate();
      return report;
   }

}