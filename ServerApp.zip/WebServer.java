/*
this java file is used to instantiate instances of WebServer class, it holds methods to
access/populate WebServer instance variables. This class inherits methods from its parent class
Customer.
*/
public class WebServer extends Customer implements VM{

//variables
   private int memory;
   private double rate;
   
//Constructor  
   WebServer(){
      this.memory = startMemory;
   }

//getters
   public int getMemory(){return memory;}
   
   public double getRate(){
      //here the rate will be set according to the customer discount
      double a = (this.memory / 8) * 10;
      if(super.getDiscount()){
         this.rate = (a + startRate) * (.80);
      }else{
         this.rate = a + startRate;
      }
      return this.rate;
   }
   
//setters
   public void setMemory(int memory){
      if(memory < 0){
         throw new IllegalArgumentException("Additional Memory input can not be less than 0");
      }else if(memory > 120){
         throw new IllegalArgumentException("Additional Memory input can not Exceeds 120 GBs");
      }else{
         this.memory = memory;
      }
   }
   
// toString
   public String toString(){
      String report = super.toString();
      report = report + "\n" +
               "Memory used : GB " + getMemory() +
               "\nMonthly Rate: $" + getRate();
      return report;
   }
   
}