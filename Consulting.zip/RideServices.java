/*
This class is a subclass of billableItems, it will inherit the methods from its parent class
and use them to populate data when an instance of this class is instantiated.
It contains additional methods to populate data specific to instances of this class only.
*/
public class RideServices extends BillableItem{
private String serviceName;
private double price;

RideServices(){
  super();
}

public void setServiceName(String serviceName){
   if(serviceName.length() < 1){
      throw new IllegalArgumentException("Invalid service name entered, please try again");
   }else{
      this.serviceName = serviceName;   
   }
}

public void setPrice(double price){
   if(price <= 0){
      throw new NumberFormatException("Price Entered is not valid try again");
   }else{
      this.price = price;
   }
}

public String getServiceName(){
   return serviceName;
}

public double getPrice(){
   return getPrice();
}

public String toString(){
   String report = super.toString();
                  report = report + "\n"
                  + "Ride Service Name: " + this.serviceName + "\n"
                  + "Charge Incurred: " + super.getChargeIncurred(this.price);
   return report;
}

}//class end