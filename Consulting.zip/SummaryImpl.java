/*
Wajaat Shah
IT-206-001
11/17/2019
Programming Assignment 8

This program is designed to help the staff of a consulting company to keep track 
of billings filled by employees for reimburstment of expenses and wages. This program is equipped
keep track of different type of reimburstment charge. Employees are able to select reimburstment
for hours they worked, personal car travel expenses, and if they use a ride service for 
commute.
The user is presented with a menu from where they will select a certain task to be carried out by the
program.
The user will be required to input the following inputs:
- the type of billable item
- the name of the employee filling expenses
- the day of week charge occured
Depending on the type of billable item the user will have to input
  when the billable items is for employee hours
  - number of hours worked by employee
  - the hourly pay of the employee
  when the billable item is for personal car travel
  - the employees carpooling with
  - the distance traveled
Upon completion the users are able to select options from a prompted menu to 
see all the filled expenses, the type of expenses, and the amount charged.
*/

import javax.swing.*;

public class SummaryImpl{
public static BillableItem[] billableItemsArray = new BillableItem[100];
public static int menuChoice = 0;
public static BillableItem b;
public static int currentPosition = 0;
public static boolean flag = false;
public String[] carpoolingEmployees = new String[4];


public static void main (String[] args){
   menuChoice = getMenuOption();
        //menu
        while (menuChoice != 5) {
            switch (menuChoice) {
                case 1://add billable item
                    addBillable();
                    menuChoice = getMenuOption();
                    break;

                case 2://Display all Billable Items
                    displayAllBillables();
                    menuChoice = getMenuOption();
                    break;

                case 3://Display total for billable service (no travel)
                    displayTotalServices();
                    menuChoice = getMenuOption();
                    break;

                case 4://Display Employees who carpooled (drivers included)
                    displayCarpoolEmps();
                    menuChoice = getMenuOption();
                    break;

                case 5://exit
                    JOptionPane.showMessageDialog(null, "Thank You");
                    break;
            }
        }

}//main end

//1 add billable item
public static void addBillable(){
   
   //the program will get the type of billable item and validate input
   flag = false;
   int itemType = 0;
   do{
      try{
         itemType = Integer.parseInt(JOptionPane.showInputDialog("Enter the number for the type of Billable item\n" + 
                        "1) Employee Hours expense\n2) Personal Car Expense\n3) Ride Share Expense"));
                        flag = true;
      }catch(NumberFormatException n){
         flag = false;
      }
         if((itemType < 1 || itemType > 3) || flag == false){
            JOptionPane.showMessageDialog(null, "Billable Item Selection Is Invalid");
            flag = false;
         }
   }while(flag == false);
   
   //here the program is creating billable item according to above selection
   switch(itemType){
      case 1:
            b = new BillableHours();
            break;
      case 2:
            b = new PersonalCarMileage();
            break;
      case 3:
            b = new RideServices();
            break;
           
      default :
   }
            
   //here the program is populating instance created above with name and validating the input
   flag = false;
   do{
      try{
         b.setEmpName(JOptionPane.showInputDialog("Enter the Employee Name"));
         flag = true;
      }catch(IllegalArgumentException i){
         JOptionPane.showMessageDialog(null, i.getMessage());
         flag = false;
      }
   }while(flag == false);
   
   //here the program is populating instance with day of weeek
   // and creating a menu for days to show user
   String[] dayChoices = {"Monday","Tuesday","WednesDay","Thursday","Friday"};
   String dayMenu = "";
      for(int i = 0; i < dayChoices.length; i++){
         dayMenu = dayMenu + i + ") " + dayChoices[i] + "\n";
      }
      
   //here the program is getting input from user for day and validating the input
   flag = false;
   int daySelected = 0;
   do{
      try{
         daySelected = Integer.parseInt(JOptionPane.showInputDialog("Enter number to select day\n" + dayMenu));
         flag = true;
      }catch(NumberFormatException n){
         flag = false;
      }
         if((daySelected < 0 || daySelected > 4) || flag == false){
            JOptionPane.showMessageDialog(null, "Day Selection Is Invalid, try again");
            flag = false;
         }
   }while(flag == false);
   
   //adding the day to the above created instance
   b.setDayOfWeek(dayChoices[daySelected]);
   
   //populating remaing methods according to their class type
   if(b instanceof BillableHours){
      
      //casting b to billableHours
      BillableHours bH = (BillableHours) b;
      
      //here the user will add Num of Hoursand the program will valudate the input
      flag = false;        
      int numHours = 0;
      do{
            try{
               bH.setNumHours(Integer.parseInt(JOptionPane.showInputDialog("Enter the number of Hours worked by employee")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, n.getMessage());
               flag = false;
            }
      }while(flag == false);
      
      //here the user will be adding Hourly Rate and the input will be validated
      flag = false;        
      double hourlyRate = 0;
      do{
            try{
               bH.setHourlyRate(Double.parseDouble(JOptionPane.showInputDialog("Enter the hourly rate for employee")));
               flag = true;
            }catch(NumberFormatException n){
               JOptionPane.showMessageDialog(null, n.getMessage());
               flag = false;
            }
      }while(flag == false);  
          
      //here the program is calculating the charge incurred and setting the instance in the array
      billableItemsArray[currentPosition] = bH;
      currentPosition ++;
   
   }else if(b instanceof PersonalCarMileage){
      //Casting instance as a Personal Car Travel instance
      PersonalCarMileage bP = (PersonalCarMileage) b;
      
      duplicateCarpool(bP.getEmpName(), bP.getDayOfWeek());
      
      if(flag == true){
            //here the user will enter carpooling employees and the input will be validated
            flag = false;
            String[] newArray = new String[4];
            int carpoolCounter = 0;
            String empInCar = "";
            do{
               empInCar = JOptionPane.showInputDialog("Enter names of Employees in Car Or enter 1 to quit");
                  if(empInCar.length() < 1){
                     JOptionPane.showMessageDialog(null, "Invalid Entry Made");
                     flag = false;
                  }else if(!(empInCar.equals("1"))){
                     newArray[carpoolCounter] = empInCar;
                     carpoolCounter ++;
                  }
            }while(flag == false && !(empInCar.equals("1")) && carpoolCounter < newArray.length);
            
            //setting the array created above to the instance carpool array
            bP.setCarpoolEmps(newArray);
            
            //here the user will input the distance for personal car mileage
            do{
               try{
                  bP.setDistance(Double.parseDouble(JOptionPane.showInputDialog("Enter the distance covered in Personal Car Travel")));
                  flag = true;
               }catch(NumberFormatException n){
                  JOptionPane.showMessageDialog(null, n.getMessage());
                  flag = false;
               }
            }while(flag == false);
            
            //here the program is calculating the charge incurred and setting the instance in the array
            billableItemsArray[currentPosition] = bP;
            currentPosition ++;   
       }   
      
    }else if(b instanceof RideServices){
    //the billable instance is being cast as a RideService instance
      flag = false;
      RideServices bR = (RideServices) b;
      
      //here the program is checking for duplicate entries for employees that carpooled and billed on same day
      boolean x = duplicateCarpool(bR.getEmpName(), bR.getDayOfWeek());
      if(x == true){
         x = rideServiceLimit(bR.getEmpName(), bR.getDayOfWeek());
      }
      
      if(x == true){
            //this block of code will get the service name form user and store the value in the instance of RideService
            do{
               try{
                 bR.setServiceName(JOptionPane.showInputDialog("Enter the name of ride service use"));
                 flag = true;
               }catch(IllegalArgumentException i){
                  JOptionPane.showMessageDialog(null, i.getMessage());
                  flag = false;
               }
            }while(flag == false);
            
            //here the program will get the price of the ride service and validate for invalid entries
            //then set the value to the instance varaible
            flag = false;
            do{
               try{
                  bR.setPrice(Double.parseDouble(JOptionPane.showInputDialog("Enter the price of ride service")));
                  flag = true;
               }catch(NumberFormatException n){
                  JOptionPane.showMessageDialog(null, n.getMessage());
                  flag = false;
               }
            }while(flag == false);
            
            //setting the instance into the array
            billableItemsArray[currentPosition] = bR;
            currentPosition ++;    
       }
      
      }//end of if statement for type of billable item

}//end of addBillable method

// ***********************************************************
//2 display billable items
//this block of code is used to go through the billable itens array and
//display all items in the the array
public static void displayAllBillables(){
   if(currentPosition <= 0){
      JOptionPane.showMessageDialog(null, "There are no Billable Items to Show");
   }else{
      String report = "";
      for(int i = 0; i < billableItemsArray.length && !(billableItemsArray[i] == null); i++){
         report = report + "* " + billableItemsArray[i] + "\n";  
      }
      JOptionPane.showMessageDialog(null, report);
   }
}


//************************************************************
//3 display total for hours
public static void displayTotalServices(){
   if(currentPosition <= 0){
      JOptionPane.showMessageDialog(null, "There are no Billable Items to Show");
   }else{
      String report = "";
      double total = 0;
      //this code will go through the billableItems array and find instances of hours worked by employees
      for(int i = 0; i < billableItemsArray.length && !(billableItemsArray[i] == null); i++){
         if(billableItemsArray[i] instanceof BillableHours){
            report = report + "\n* " + billableItemsArray[i];
            total = total + billableItemsArray[i].getChargeIncurred();
         }
      }
      report = report + "\n\nTotal For Services :  " + total; 
      JOptionPane.showMessageDialog(null, report);
   }
}

// ***********************************************************
//4 display all carpool employees
public static void displayCarpoolEmps(){
   if(currentPosition <= 0){
      JOptionPane.showMessageDialog(null, "There are no Billable Items to Show");
   }else{
      String[] newArray1 = new String[100];
      String report = "";
      int counter = 0;
         //this block of code will go through the billableitems array and find instances of PersonalCarMileage
         for(int i = 0;!(billableItemsArray[i] == null) && i < billableItemsArray.length; i++){
            if(billableItemsArray[i] instanceof PersonalCarMileage){
            String[] newArray2 = billableItemsArray[i].getCarpoolEmps();//oooooooooooo
            
               //this block of code will get the name of the driver and add it to the array
               String z = billableItemsArray[i].getEmpName();
                     boolean y = contains(z, newArray1);
                     if(y == false){
                        newArray1[counter] = z;
                        counter++;
                     }
               
               //this code will be carried out to assign the report with values if the array with employee names
               // is empty
               if(newArray1[0]==null){
                  for(int b = 0; b < newArray2.length && !(newArray2[b]==null); b++){
                     newArray1[counter] = newArray2[b];
                     counter ++;
                  }
               }else{
                  //this block of code will populate the carpooling employee names if the array already has names in it
                  for(int a = 0; a < newArray2.length && !(newArray2[a] == null); a++){
                     String str = newArray2[a];
                     boolean x = contains(str, newArray1);
                        if(x == false){
                           newArray1[counter] = str;
                           counter ++;
                        }
                  }
               }

            }
         }
         
         //this code will create a list all carpooling employees
         for(int z = 0; z < newArray1.length && !(newArray1[z] == null); z++){
            report = report + newArray1[z] +"\n";
         }
         JOptionPane.showMessageDialog(null, report);
   }
}

//this method is used to provide the user with a menu to select what type of action they want to carry out
// it will then return that selection made
public static int getMenuOption(){
   int menuChoice;    
      try{
         menuChoice = Integer.parseInt(JOptionPane.showInputDialog(
         "Choose a number to continue:"
         + "\n1 : Add Billable Item"
         + "\n2 : Display all Billable Items"
         + "\n3 : Display Total for Billable Service (No Travel)"
         + "\n4 : Display Carpooling Employee (Driver Includede)"
         + "\n5 : Quit"
         ));
      }
      catch (NumberFormatException e){
         menuChoice = 0;
      }
      if ((menuChoice < 1 || menuChoice > 5)){
         JOptionPane.showMessageDialog(null, "Menu choice is invalid, please use a valid option.");
      }
      while(menuChoice <1 || menuChoice >5){
      menuChoice = getMenuOption();
   } 
      return menuChoice;
}

//this method when called will take in a name and day of the week and validate an employee
// is not carpooling and billing on the same day
public static boolean duplicateCarpool(String name, String day){
   for(int i = 0; i < billableItemsArray.length && !(billableItemsArray[i] == null); i++){
      if(billableItemsArray[i] instanceof PersonalCarMileage){
         String[] names = billableItemsArray[i].getCarpoolEmps();
         String dayOfWeek = billableItemsArray[i].getDayOfWeek();
            for(int x = 0; x < names.length && !(names[x]==null); x++){
               if(names[x].equals(name) && dayOfWeek.equals(day)){
                  JOptionPane.showMessageDialog(null, "Employee has carpooled and can not file for charges on the same day");
                  return false;
               }  
            }
      }
   }
   return true;
}

//this method will take in a string and an array, it will then validate that the string is not already in the array
public static boolean contains(String str, String[] newArray1){
   for(int i = 0; i < newArray1.length && !(newArray1[i] == null); i++){
      if(str.equals(newArray1[i])){
         return true;
      }
   }
   return false;
}

//this method will go through the array of billable items and ensure no employee has filed for ride services more than 2 times
public static boolean rideServiceLimit(String name, String day){
   int counter = 0;
   for(int i = 0; i < billableItemsArray.length && !(billableItemsArray[i]==null); i++){
      if(billableItemsArray[i] instanceof RideServices){
         String a = billableItemsArray[i].getEmpName();
         String d = billableItemsArray[i].getDayOfWeek();
         if(a.equals(name) && d.equals(day)){
            counter++;
         }
      }
   }
   if(counter > 1){
      JOptionPane.showMessageDialog(null, "The Employee has already used ride service 2 times in the same day");
      return false;
   }
   return true;
}

}//class end