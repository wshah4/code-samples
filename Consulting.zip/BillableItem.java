/*
This class is an abstract class which holds methods and variables for its subclasses to
use and populate data for the subclass instance to inherit.
*/
public abstract class BillableItem{
private String empName;
private String dayOfWeek;
private double chargeIncurred = 0;
private String[] carpoolEmps = new String[4];

//constructor which can not be instantiated directly
BillableItem(){

}

// getters & setters used to populate and retrieve data
public void setEmpName(String empName){
   if(empName.length() <1){
      throw new IllegalArgumentException("Name entered is Invalid, try again");
   } else {
      this.empName = empName ;
   }
}

public void setDayOfWeek(String dayOfWeek){
   this.dayOfWeek = dayOfWeek;
}

public String[] getCarpoolEmps(){
   return carpoolEmps;
}

public double getChargeIncurred(){
   return this.chargeIncurred;
}

//this method will take in a double value and set the charge incurred and round it to the closest dollar
public double getChargeIncurred(double chargeIncurred){
   
   double a = chargeIncurred;
   int b = (int) a;
   double remainder = a - b;
   double e = 0;
   
   if( remainder < 0.50){
      e = (a - remainder);
   } else {
      e = (a + (1 - remainder));
   }
   this.chargeIncurred = e;
   return e;
}

public String getEmpName(){
   return empName;
}

public String getDayOfWeek(){
   return dayOfWeek;
}

//method which calls all values listed in order to create a report
public String toString(){
   String report = "Employee Name: " + this.empName + "\n"
                 + "Day of Week: " + this.dayOfWeek;
   return report;
}

}//class end