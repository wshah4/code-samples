/*
This class is a subclass of billableItems, it will inherit the methods from its parent class
and use them to populate data when an instance of this class is instantiated.
It contains additional methods to populate data specific to instances of this class only.
*/
public class PersonalCarMileage extends BillableItem{
private String[] carpoolEmps;
private double distance;

//Constructor
PersonalCarMileage(){
super();
}

//getters and setters to populate and retrieve data
public void setCarpoolEmps(String[] carpoolEmps){
   this.carpoolEmps = carpoolEmps;
}

public void setDistance(double distance){
   if(distance <= 0){
      throw new NumberFormatException("Distance entered is inalid, please try again");
   }else{
      this.distance = distance;
   }
}

public String[] getCarpoolEmps(){
   String[] newArray = carpoolEmps;
   for(int i =0; i < newArray.length && !(carpoolEmps[i] == null) ; i++){
      newArray[i] = carpoolEmps[i];
   }
   return newArray;
}

public double getDistance(){
   return distance;
}

//this method when called will call values and create a report of this instance
// it will also loop through the carpooling employees array and add their name to the report
public String toString(){
   String names = "";
   for(int i =0 ; i < carpoolEmps.length && !(carpoolEmps[i] == null); i++){
      names += carpoolEmps[i] + "\n";
   }
   String report = super.toString();
                  report = report + "\n"
                  + "Charge Incurred: " + getChargeIncurred(this.distance) +"\n"
                  + "Employees in Car: " + "\n" + names;
   return report;
}

}//class end