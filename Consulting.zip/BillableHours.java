/*
This class is a subclass of billableItems, it will inherit the methods from its parent class
and use them to populate data when an instance of this class is instantiated.
It contains additional methods to populate data specific to instances of this class only.
*/
public class BillableHours extends BillableItem{
private int numHours;
private double hourlyRate;

//constructor calls the parent class constructor
public BillableHours(){
   super();
}

//getters & setters to populate and retrieve data
public void setNumHours(int numHours){
   if(numHours < 0){
      throw new NumberFormatException("Number of Hours cant be less than zero");
   } else {
      this.numHours = numHours;
   }
}

public void setHourlyRate(double hourlyRate){
   if(hourlyRate <= 0){
      throw new IllegalArgumentException("Houlry Rate cant be less than zero");
   }else{
      this.hourlyRate = hourlyRate;
   }
}

public int getNumHours(){
   return numHours;
}

public double getHourlyRate(){
   return hourlyRate;
}

//this method will call the values of variables in this class and create report of the instance
public String toString(){
   String report = super.toString();
   report = report + "\nCharge Incurred: " + getChargeIncurred(this.numHours * this.hourlyRate);
   return report;
}

}//class end