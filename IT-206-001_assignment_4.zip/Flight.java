/*

This body of code is used to create object instances in the implemetation class.
When an object is instantiated this class will set all the default values,
and provide methods to change or see the values of instances.

*/
public class Flight {
   //class variables
	public static final int maxEconomy = 300;
	public static final int maxFirstClass = 30;
	private String id;
	private String route;
   private int economy;
   private int firstClass;
   private static String ticketType;//false is firstClass
	private double ticketCost;
   private static int numFlights;
   private static double totalRevenue;
	
   //constructor
	public Flight(){

	}
   
   /*
   The following line of code are accessors (ie. get methods) used to access values outside this class
   and mutators  (ie. set methods) which set values of variable for object instances of this class.
   They are also equipped with validations, so if users input is invalid they will throw exceptions which
   will be dealt with in the implemtation class.
   */
   	
	public String getId(){
		return id;
	}
   
	public void setId(String id) {
		this.id = id;
	}
   
	public String getRoute(){
     return route;
	}
   
	public void setRoute(String route) {
      if(route.equals("") || route.equals(null)){
         throw new IllegalArgumentException ("Invalid route entered, please try again");
      } 
		this.route = route;
	}
   
   public String getTicketType(){
      return ticketType;
   }
   
   public void setTicketType(String ticketType){
      if((ticketType.equals("")|| (!(ticketType.equalsIgnoreCase("e")) && !(ticketType.equalsIgnoreCase("f"))))){
         throw new IllegalArgumentException("Invalid entry was made for ticket type, please try again");
      }
      this.ticketType = ticketType;
   }
   
   public int getEconomy(){
      return economy;
   }
   
   public void setEconomy(int economy){
      if(economy < 0 || economy > 300){
         throw new NumberFormatException("Invalid number of tickets entered");
      }
      if((getEconomy() + economy) > maxEconomy){
         throw new IllegalArgumentException("Tickets exceed maximum number of tickets allowed");
      }
      this.economy = economy;
   }
   
   public int getFirstClass(){
      return firstClass;
   }
   
   public void setFirstClass(int firstClass){
      if(firstClass < 0 || firstClass > maxFirstClass){
         throw new IllegalArgumentException("Invalid number of tickets entered");
      }
      if((getFirstClass() + firstClass) > maxFirstClass){
         throw new IllegalArgumentException("Tickets excedd maximum number of tickets allowed");
      }
      this.firstClass = firstClass;
   }
   
	public double getTicketCost(){
		return ticketCost;
	}
   
	public void setTicketCost(double ticketCost){
      if(ticketCost <= 0){
         throw new IllegalArgumentException("Invalid cost entered");
      }
		this.ticketCost = ticketCost;
	}
   
   public static int getNumFlights(){
      return numFlights;
   }
   
   public void setNumFlights(int position){
      this.numFlights = position;
   }
   
   public double getTotalRevenue(){
    totalRevenue = (getEconomy() * getTicketCost()) + ((getFirstClass() + 270)*getTicketCost());
     return totalRevenue;
   }
 
   //this method will generate a report with data from specific instances
   public String toString(){
   String report ="Flight ID: " + getId() 
                           + "\n Flight Route: " + getRoute()
                           + "   Economy seats sold: "+getEconomy()
                           + "   First Class seats sold: "+getFirstClass()
                           + "\n Economy tickets available: "+(maxEconomy - getEconomy())
                           + "   FirstClass tickets available: "+(maxFirstClass - getFirstClass())
                           + "   Ticket Cost: $ "+getTicketCost()
                           + "\n Total revenue: "+(getTotalRevenue());
      return report;
   }
}
