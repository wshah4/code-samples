/*

Wajaat Shah
IT-206-001
10/06/2019

Description:
This program was created in order to facilkitate PAtriot flight emplpoyers with their process of flight logging and 
ticket sales. This program is designed to aloow the user to input a single fight or a collection of flights in the program.
The program will also allow user the option remove a flight from the collection, as long as there are flights 
available to delte. The user can choose to sell tickets to a certain flight or display the flights which have been added.
Finally the user is provided with the option of leaving the program as well.

The user is required to input the following inputs:
The user must input a selection for the menu prompt.
The user must enter an id for each flight which is beeing added or removed, these flight id's are validated for proper formatting.
The user must enter the number of tickets being sold, the ticket price and the type of tiket being sold.

The program then generates a report upon users request which show all the information added to the flight collection
along with the data which is input by the user.
*/


import javax.swing.*;
public class FlightApp {

//the program will declare the flightLog reference name for an array of Flight Class instances
public static Flight[] flightLog;
private static int menuChoice;
public static int position = 0;
public static boolean flag;

   //main method contains the switch/case statement which will work as a-
   // menu for the users to loop thrpugh until not neccessary anymore
	public static void main(String[] args) {
      final int maxFlights = 15;
      flightLog = new Flight[maxFlights];
      
      menuChoice = getMenuOption();
      while(menuChoice != 5){
      switch(menuChoice){
            case 1://add flight
               addFlight(flightLog);
               flightLog[position].setNumFlights(position++);
               menuChoice = getMenuOption();
               break;
               
            case 2://remove flight
               removeFlight();
               //position = position - -1;
               menuChoice = getMenuOption();
               break;
               
            case 3://sell flight ticket
               sellFlightTicket(flightLog);
               menuChoice = getMenuOption();
               break;
               
            case 4://display flights
               JOptionPane.showMessageDialog(null, displayFlights(flightLog));
               menuChoice = getMenuOption();
               break;
               
            case 5://exit
               exitMethod();
               break;
         }
       }
	 }
   
   
   //This method contains the code required to add flight object instance into the flights collection
   public static void addFlight(Flight[] flightLog){
      flag = false;
      //this loop allows the program to loop through until the user inputs a valid input
      do{
         //the program will create an object instance outside the collection of flight-
         // objects abd call the addId method and Route method to populate those fields with data
         if(position < flightLog.length){
               Flight oneFlight = new Flight();
               oneFlight.setId(addId());
            try{
               oneFlight.setRoute(addRoute());
            }
            catch(IllegalArgumentException i){
               JOptionPane.showMessageDialog(null,"Flight could not be added to the flight log: " + i.getMessage());
                  flag = false;
            }
               flightLog[position] = oneFlight;
               flag = true;
         }
         else{
           JOptionPane.showMessageDialog(null, "The log does has reached maximum flights");
         }
       } while (flag == false);
   }
   
   //this method here will be called inorder to prompt the user for the flight Id,
   // while repeating in alopp if an invalid id is entered.
	public static String addId(){
      flag = false;
      String id = "";
      do{
         try{
         flag = true;
         id = (JOptionPane.showInputDialog("Enter the flight Id"));
         validateId(id);
         validateDuplicate(id);
         } catch (IllegalArgumentException i){
            flag = false;
         }
       } while(flag == false || id.length() !=6 || id.equals(""));
         return id;
	}
	
   //this method is called inorder to take in user input to populate the route variable of an object instance
	public static String addRoute(){
    flag = false;
    String route = "";
       do{
         try{
            route = (JOptionPane.showInputDialog("Enter the flight route"));
            flag = true;
            } catch (IllegalArgumentException i){
             flag = false;
         }
       }
     while (flag == false);
     return route;
	}
   
   //this method is called in order to remove a flight from the collection of flights
   // it takes in user input and validates for a matching value
   public static void removeFlight(){
      //1 get the id from user, and validate it
      if(position >= 1){
         String idFinder = JOptionPane.showInputDialog(displayFlights(flightLog) + "\nEnter the ID number to mark a flight for deletion");
         while(idFinder.equals("") || (idFinder.length() != 6)|| (flag == false)){
            JOptionPane.showMessageDialog(null, "ID number not found, please try again");
            idFinder = JOptionPane.showInputDialog("Enter the ID number to select a flight");
            validateId(idFinder);
         }
              //here the program will go through the collection of flights and find the index/location
              // of a flight id matching the id input by the user above.
              int i = 0;
              int index = -1;
              flag = false;
                 for(i=0; i < flightLog.length - 1 && flag == false; i++){
                  if(flightLog[i] == null){
                     return;
                  }
                  if(flightLog[i].getId().equals(idFinder)){
                     index = i;
                     flag = true;
                  }
                  }
                 
                 //here the code will start to shift the array/collection values to the right of the value at the index value
                 // in order to fill in the empty spot created due to deltion above.
                 while(flightLog[index] != null && index < flightLog.length - 1){
                  flightLog[index] = flightLog[index+1];
                     index ++;
                 }
                 flightLog[index] = null;
                 position --;
                  
               JOptionPane.showMessageDialog(null, displayFlights(flightLog));
      }else{
         JOptionPane.showMessageDialog(null, "There are no flights to delete");
         menuChoice = getMenuOption();
      }
        
   }
   
   
   //This method when called will sell ticket to flights a user inputs
   public static void sellFlightTicket(Flight[] flightLog){
      if(position >= 1){
      //here the code will get the id, validate it, and loop until a valid id is found
      String idFinder = JOptionPane.showInputDialog(displayFlights(flightLog) + "\nEnter the ID number to select a flight");
      while(idFinder.equals("") || (idFinder.length() != 6)){
         JOptionPane.showMessageDialog(null, "ID number not found, please try again");
         idFinder = JOptionPane.showInputDialog("Enter the ID number to select a flight");
      }
            
         // this block of code will loop throught he array and find the matching flight to that which the user has entered
            int i = 0;
            for(i = 0; i < flightLog.length; i++){
               if(flightLog[i].getId().equals(idFinder)){
                  do{
                     //this line will get the genreal cost for a ticket
                     if(flightLog[i].getTicketCost() <= 0){
                     flightLog[i].setTicketCost(addTicketCost());
                     }
                     
                     //get the ticket type and will validate for invalid entries
                     try{
                     flightLog[i].setTicketType(JOptionPane.showInputDialog("Type of ticket being sold: \n" + "Enter 'E' for economy or 'F' for firstClass"));
                     } catch (IllegalArgumentException iae){
                        flag = false;
                        JOptionPane.showMessageDialog(null, iae.getMessage());
                     }
                                                              
                        //This block of code will assign the amount of economy or first class seats being sold
                           if(flightLog[i].getTicketType().equalsIgnoreCase("E")){
                              try{
                                 flightLog[i].setEconomy(flightLog[i].getEconomy() + addEconomy());
                                 flightLog[i].setFirstClass(flightLog[i].getFirstClass());
                                 flag = true;
                              }catch(NullPointerException n){
                                 JOptionPane.showMessageDialog(null, "economy numbers are null");
                                 flag = false;
                              }
                           }else{
                              try{
                                 //assigning the firstclass variable as user input, and the economy seats equal to itself
                                 flightLog[i].setFirstClass(flightLog[i].getFirstClass() + addFirstClass());
                                 flightLog[i].setEconomy(flightLog[i].getEconomy());
                              }catch(NullPointerException n){
                                 JOptionPane.showMessageDialog(null, "firstClass numbers are null");
                              }
                           } 
                      } while(flag == false);
                   
                   break;       
               }
            }  
         }else{
            JOptionPane.showMessageDialog(null, "There no flights to sell a ticket for.");
            menuChoice = getMenuOption();
         }          
   }
   
   //when called this method will prompt the user for ticket cost and return its value
   public static double addTicketCost(){
      double ticketCost = -1;
      //the code will prompt, read and validate the users input for the flights route
      do {
         try{
            ticketCost = Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the ticket"));
            flag = true;
         } catch (NumberFormatException n){
            JOptionPane.showMessageDialog(null, "Invalid ticket price was entered, please try again");
            flag = false;
         }
      } while (flag == false);
      return ticketCost;
   }
   
   //when called this code will prmpt the user to add the number of economy seats being sold
   public static int addEconomy(){
      flag = false;
      int economy = 0;
      //the user must input valid input for this loop to end and return a value.
       do{
        try{
            economy = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of economy tickets"));
            flag = true;
            } catch (NullPointerException n){
               flag = false;
            }
         } while (flag == false);
      return economy;
   }
   
   //this method will allow the user to enter the number of first class tickets being sold and return its value
   public static int addFirstClass(){
      int firstClass = 0;
      try{
      firstClass = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of firstClass tickets"));
      } catch (IllegalArgumentException i){
         JOptionPane.showMessageDialog(null, i.getMessage());
         firstClass = -1;
      }
      return firstClass;
   }
  
   // this method is used to prompt the user with options to choose form for the program to carry out a specific task
   public static int getMenuOption(){
     int menuChoice;    
         try {
               menuChoice = Integer.parseInt(JOptionPane.showInputDialog(
                           "Choose a number to continue:"
                           + "\n1 : Create Flight"
                           + "\n2 : Remove Flight"
                           + "\n3 : Sell Flight Ticket"
                           + "\n4 : Display Flights"
                           + "\n5 : Exit the Program"
                           ));
              }
              catch (NumberFormatException e){
                 menuChoice = 0;
              }
              if ((menuChoice < 1 || menuChoice > 5)){
               JOptionPane.showMessageDialog(null, "Menu choice is invalid, please use a valid option.");
              }
         while(menuChoice <1 || menuChoice >5){
            menuChoice = getMenuOption();
         } 
         return menuChoice;
   }
   
   //this method is called to output the flights which are currently input in array and display them to the user
   public static String displayFlights(Flight[] flightLog){
      String report = "";
      if(position >= 1){
            for(int i = 0; (i < flightLog.length) ; i++){
                if(flightLog[i] != null){
                  report = report + flightLog[i] + "\n";
                }
            } 
      }else{
         JOptionPane.showMessageDialog(null, "There are no flights to display");
         menuChoice = getMenuOption();
      }
         return report;
   }
   
   //this method is used to validate the users input of a flights id
   public static void validateId(String id){
   int i = 0 ;
         //here the code will check the first two characters of the user id to
         //validate both for a capital letter
         while((i <= id.length()-1 && (flag == true)) && (id.length() == 6)){
         if(i<2){
            if(Character.isUpperCase(id.charAt(i))){
               flag = true;
               i++;
            }else{
               flag = false;
            }
         }
          //here the code will check the last four characters of the user id to
         //validate both for a number
          if(i>=2){
            if(Character.isDigit(id.charAt(i))){
               i++;
            }else{
               flag = false;
            }
          }
        }
          
          //the user will be prompted by an error message and given the menu choices again
          if(flag == false || id.equals("") || id.length() != 6){
             JOptionPane.showMessageDialog(null, "*************Invalid Id entered******************\n Please enter a capital letter for the first two characters of the Id,\n a number for the last four digits");
             flag = false;
          }
          
      }
      
      public static void validateDuplicate(String id){
         int i = 0;
         for(i = 0; (i < flightLog.length - 1) && (position > 0) && (flightLog[i] != null);i++){
            if(flightLog[i].getId().equals(id)){
               JOptionPane.showMessageDialog(null, "The flight Id already exists, try again");
               flag = false;
               return;
            }
         }
      }
      
      //this method will calculate the toal revenue accross all of the flights entered and
      // display there values, upon doing so the program will end
      public static void exitMethod(){
         int i = 0;
         double revenue = 0;
            for(i = 0; (i < flightLog.length) && (i < position); i++){
               revenue += flightLog[i].getTotalRevenue();
            }
         String report = "Current number of Flights:  " + position +
                         "Total reenue earned across all flights: $" + revenue;
         JOptionPane.showMessageDialog(null, report);
      }
   }

