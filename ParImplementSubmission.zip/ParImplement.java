/*

Wajaat Shah
IT-206-001
10/06/2019

Description:
The purpose of creating this program was to facilitate the George Mason Staff help keep track of Participants which have eithe registred 
with or will enroll with the George Mason Gen X program. This program is designed in order to allow its user to carry out multiple
functions, these function are the following:
  -Register Participant
  -Enroll Participants into a given course
  -Remove a participant from a given course
  -View all participants
  -Exit the program
  
The user is required to input which acction they would like carried out and the when a selection is made the program will carry out
instructions accordingly. The following are other inputs required from the user to complete the program:
  -The user must entered whether a participant is partnered with an orgnization or not
  -The user is required to enter the participants name, age, gender, cell number, and email. Upon reciving each input the program will validate
   all inputs.
 -Depending pon the type of participant the user must also provide the orginization name if they are partnered and the percent discount recieved

The Program will provide the user with error messages if there is an invalid input and it will prompt the user to do so until a valid input is made.
When prompted to or when the program reaches its maximum number of participants it will gather all input values for each participant and provide a
report with details
 */

import javax.swing.*;
//class varaible decleration

public class ParImplement {

    public static boolean flag = false;
    public static int menuChoice = 0;
    public static int maxParticipants = 50;
    public static int participantArrayIndex = 0;
    public static int currentParticipant = 0;
    public static Participant p1;
    public static Participant[] participantArray = new Participant[maxParticipants];

//main method will call menu and intake the user input and carry out methods depending on user input
    public static void main(String[] args) {
        menuChoice = getMenuOption();
        //menu
        while (menuChoice != 5) {
            switch (menuChoice) {
                case 1://register
                    participantArray[participantArrayIndex] = createParticipant();
                    participantArrayIndex++;
                    menuChoice = getMenuOption();
                    break;

                case 2://enroll
                    enrollParticipant();
                    menuChoice = getMenuOption();
                    break;

                case 3://remove enrolled participant
                    removeEnrollment();
                    menuChoice = getMenuOption();
                    break;

                case 4://print record of a participant
                    JOptionPane.showMessageDialog(null, displayParticipant());
                    menuChoice = getMenuOption();
                    break;

                case 5://exit
                    JOptionPane.showMessageDialog(null, "Thank You");
                    break;
            }
        }

    }//main end

    //this method allows users to see a menu with numbers to select, while loop[ing thorugh invalid entries and return the menu value
    public static int getMenuOption() {
        // int menuChoice;    
        try {
            menuChoice = Integer.parseInt(JOptionPane.showInputDialog(
                    "Choose a number to continue:"
                    + "\n1 : Register Participant"
                    + "\n2 : Enroll in Class"
                    + "\n3 : Remove Enrolled Participant from course"
                    + "\n4 : Display Participant Record"
                    + "\n5 : Quit"
            ));
        } catch (NumberFormatException e) {
            menuChoice = 0;

        }
        if ((menuChoice < 1 || menuChoice > 5)) {
            JOptionPane.showMessageDialog(null, "Menu choice is invalid, please use a valid option.");
        }
        while (menuChoice < 1 || menuChoice > 5) {
            menuChoice = getMenuOption();
        }
        return menuChoice;
    }

    // 1) register 
    // this method is used to instantiate a participant class object in order to register a participant into the Participants Array
    // it will call other methods to populate this object with values
    public static Participant createParticipant() {
        String participantType = "";
        flag = false;
        do {
            try {
                participantType = JOptionPane.showInputDialog("Is the participant partnered with an orginization\nEnter 'Y' for yes 'N' for no");
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
            // this block of code is used to verify what type of participant to create,
            // depending on if the participant is a partnered participant or a normal participant
            if (participantType.equalsIgnoreCase("N") && flag == true) {
                p1 = new Participant(inputName(), inputAge(), inputGender(), inputCell(), inputEmail());
            } else if (participantType.equalsIgnoreCase("Y") && flag == true) {
                p1 = new PartneredParticipant(inputName(), inputAge(), inputGender(), inputCell(), inputEmail(), inputOrgName(), inputDiscount());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid participant type");
                flag = false;

                for (int i = 0; (i < participantArray.length) && (participantArray[i] != null); i++) {
                    if (p1.equals(participantArray[i])) {
                        JOptionPane.showMessageDialog(null, "This participant is already enrolled");
                        flag = false;
                        menuChoice = getMenuOption();
                    } else {
                        JOptionPane.showMessageDialog(null, "There are no classes to delete");
                        menuChoice = getMenuOption();
                    }
                }
            }
        } while (flag == false);
        return p1;
    }
    //name
    // when called this method will prompt, read, and validate user input NAME and return its value

    public static String inputName() {
        String name = "";
        flag = false;
        Participant clone = new Participant();
        do {
            try {
                name = JOptionPane.showInputDialog("Enter the participant name");
                clone.setName(name);
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
        } while (flag == false);
        return name;
    }
    //age
    // when called this method will prompt, read, and validate user input AGE and return its value

    public static int inputAge() {
        int age = 0;
        flag = false;
        Participant clone = new Participant();
        do {
            try {
                age = Integer.parseInt(JOptionPane.showInputDialog("Enter the participants age"));
                clone.setAge(age);
                flag = true;
            } catch (IllegalArgumentException n) {
                JOptionPane.showMessageDialog(null, n.getMessage());
                flag = false;
            }
        } while (flag == false);
        return age;
    }
    //gender
    // when called this method will prompt, read, and validate user input GENDER and return its value

    public static String inputGender() {
        String gender = "";
        flag = false;
        Participant clone = new Participant();
        do {
            try {
                gender = JOptionPane.showInputDialog("Enter the participants gender");
                clone.setGender(gender);
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
        } while (flag == false);
        return gender;
    }
    //cell
    // when called this method will prompt, read, and validate user input CELL number and return its value

    public static String inputCell() {
        String cell = "";
        flag = false;
        Participant clone = new Participant();
        do {
            try {
                cell = JOptionPane.showInputDialog("Enter the participants cell number");
                clone.setCell(cell);
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
        } while (flag == false);
        return cell;
    }
    //email
    // when called this method will prompt, read, and validate user input EMAIL and return its value

    public static String inputEmail() {
        String email = "";
        flag = false;
        Participant clone = new Participant();
        do {
            try {
                email = JOptionPane.showInputDialog("Enter the participants email address");
                clone.setEmail(email);
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
        } while (flag == false);
        return email;
    }
    //orgName
    // when called this method will prompt, read, and validate user input AGE and return its value

    public static String inputOrgName() {
        String orgName = "";
        flag = false;
        PartneredParticipant clone = new PartneredParticipant();
        do {
            try {
                orgName = JOptionPane.showInputDialog("Enter the partnered orginization name");
                clone.setOrgName(orgName);
                flag = true;
            } catch (IllegalArgumentException iae) {
                JOptionPane.showMessageDialog(null, iae.getMessage());
                flag = false;
            }
        } while (flag == false);
        return orgName;
    }
    //discount
    // when called this method will prompt, read, and validate user input DISCOUNT and return its value

    public static int inputDiscount() {
        int discount = 0;
        flag = false;
        PartneredParticipant clone = new PartneredParticipant();
        do {
            try {
                discount = Integer.parseInt(JOptionPane.showInputDialog("Enter the discount received"));
                clone.setDiscount(discount);
                flag = true;
            } catch (IllegalArgumentException n) {
                JOptionPane.showMessageDialog(null, n.getMessage());
                flag = false;
            }
        } while (flag == false);
        return discount;
    }

    //display participants
    // this method is used to print out a report of all the participants in the participant array and the values each instance holds
    public static String displayParticipant() {
        String report = "";
        if (participantArrayIndex >= 1) {
            for (int i = 0; (i < participantArray.length) && participantArray[i] != null; i++) {
                if (participantArray[i] != null) {
                    report = report + participantArray[i] + "\n";
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "There are no participants to display");
            menuChoice = getMenuOption();
        }
        return report;
    }

    //enroll
    // this method when called will call this method will prompt users to input a name and email in order to find a participant from the array
    public static void enrollParticipant() {
        if (participantArrayIndex >= 1) {
            String name = inputName();
            String email = inputEmail();
            flag = false;
            boolean registered = false;

            do {
                for (int i = 0; i < participantArray.length && participantArray[i] != null; i++) {
                    //assigning temperary variables with the name and email from the chosen participant
                    String name2 = participantArray[i].getName();
                    String email2 = participantArray[i].getEmail();
                    if ((name.equals(name2) && email.equals(email2))) {
                        int index = i;
                        participantArray[i].setCourseArray(enrollCourse(index));
                        flag = true;
                    } else {
                        JOptionPane.showMessageDialog(null, "No registered Participant found");
                        registered = true;
                    }
                }
            } while (flag == false && registered == false);

        } else {
            JOptionPane.showMessageDialog(null, "There are no participants to enroll");
        }
    }
    //select the course name
    //this method allows users to choose a number from a menu selection to enroll in that specific class

    public static int inputCourse() {
        int courseChoice;
        try {
            courseChoice = Integer.parseInt(JOptionPane.showInputDialog(
                    "Choose a number to sign up for that course"
                    + "\n1 : Intro to Computer Basics"
                    + "\n2 : Computer Basics Intermediate"
                    + "\n3 : Computer Basics Advanced"
                    + "\n4 : Applied Computer Skill"
            ));
        } catch (NumberFormatException e) {
            courseChoice = 0;
        }
        if ((courseChoice < 1 || courseChoice > 4)) {
            JOptionPane.showMessageDialog(null, "Course choice is invalid, please use a valid option.");
        }
        while (courseChoice < 1 || courseChoice > 4) {
            inputCourse();
        }
        return courseChoice;
    }
    //checks if course is already enrolled 
    public static boolean contains(String str, Course[] arr) {
        int i;
        for (i = 0; i < arr.length && arr[i] != null; i++) {
            if (arr[i].getCourse().equals(str)) {
                return true;
            }
        }
        return false;
    }
    //set course name and price
    //this method when called creates a course object array and populates it with instances of courses selected according to the user input value from inputCourse()

    public static Course[] enrollCourse(int index) {
        int x = 0;
        Course[] selectedCourses = participantArray[index].getCourseArray();
        while (x<selectedCourses.length&&selectedCourses[x] != null) {
            x++;
        }
        if(x<selectedCourses.length)
        {
            int classChoice = inputCourse();

        //here the program will go through if conditions and when it meets a valid condition it will assign the course with a name
        // the order block of code will only allow participants to enroll if they meet the pre-requsite requirment of Intro to Computer basics
        if ((x == 0) && (classChoice == 1)) {
            boolean status1 = contains("Intro to Computer Basics", selectedCourses);
            if (status1) {
                JOptionPane.showMessageDialog(null, "you are already enrolled in this course");
             } 
            else
            {
            selectedCourses[x] = new Course("Intro to Computer Basics");
            }
        } else if ((x > 0) && (x < 3)) {
            if (classChoice == 2) {
                boolean status2 = contains("Computer Basics Intermediate", selectedCourses);
                if (status2) {
                    JOptionPane.showMessageDialog(null, "you are already enrolled in this course");
                    
                }
                else
                {
                     selectedCourses[x] = new Course("Computer Basics Intermediate");
                }
               
            } else if (classChoice == 3) {
                boolean status3 = contains("Computer Basics Advanced", selectedCourses);
                if (status3) {
                    JOptionPane.showMessageDialog(null, "you are already enrolled in this course");
                    
                }
                else
                {
                selectedCourses[x] = new Course("Computer Basics Advanced");
                }
            } else if (classChoice == 4) {
                boolean status4 = contains("Applied Computer Skills", selectedCourses);
                if (status4) {
                    JOptionPane.showMessageDialog(null, "you are already enrolled in this course");
                    
                }
                else
                {
                selectedCourses[x] = new Course("Applied Computer Skills", 150);
                }
            }
        } else if (x > 3) {
            JOptionPane.showMessageDialog(null, "Maximum number of classes allowed reached, can not enroll any more");
        } else {
            JOptionPane.showMessageDialog(null, "Intro to Computers must be taken as a pre-req to every class");
        }
        }
        else
        {
           JOptionPane.showMessageDialog(null, "Maximum number of classes allowed reached, can not enroll any more");
        }
        //this block of code will call a method which validates the participants course, in order to prevent double enrollment
       
        return selectedCourses;
    }
    //this method when called provide duplicate enrollment validation, to prevent participants from enrolling twice

    

    //remove a participant from a course
    //this method allows the program to take a participants name and email and remove them from a selected course
    public static void removeEnrollment() {
        //1 get the id from user, and validate it
        String name = inputName();
        String email = inputEmail();
        Course[] clone = new Course[3];
        flag = false;
        boolean noParticipant = false;
        int currentPosition = 0;
        if (participantArrayIndex >= 1) {
            //here the program will go through the participant array and find a Participant's Course Array and find their position
            for (int i = 0; i < participantArray.length && participantArray[i] != null; i++) {
                //assigning temporary varaibles with values for comparison between the original and copy
                String name2 = participantArray[i].getName();
                String email2 = participantArray[i].getEmail();
                if (name.equals(name2) && email.equals(email2) && participantArray[i] != null) {
                    clone = participantArray[i].getCourseArray();
                    currentPosition = i;
                    flag = true;
                } else {
                    JOptionPane.showMessageDialog(null, "No registered Participant found");
                    flag = false;
                }
            }

            //this block of code will go through the course array and find the postion of the course to be deleted and then remove it       
            if (clone.length >= 1 && flag == true) {
                int idFinder = inputCourse();
                String courseToRemove = "";

                if (idFinder == 1) {
                    courseToRemove = "Intro to Computer Basics";
                } else if (idFinder == 2) {
                    courseToRemove = "Computer Basics Intermediate";
                } else if (idFinder == 3) {
                    courseToRemove = "Computer Basics Advanced";
                } else if (idFinder == 4) {
                    courseToRemove = "Applied Computer Skills";
                } else {
                    JOptionPane.showMessageDialog(null, "Participant not enrolled in this course to remove");
                }

                int i = 0;
                int index = -1;
                flag = false;
                for (i = 0; i < clone.length - 1 && flag == false; i++) {
                    if (clone[i] == null) {
                        return;
                    }
                    if (clone[i].getCourse().equals(courseToRemove)) {
                        index = i;
                        flag = true;
                    }
                }

                //here the code will start to shift the array/collection values to the right of the value at the index value
                // in order to fill in the empty spot created due to deltion above.
                while (clone[index] != null && index < clone.length - 1) {
                    clone[index] = clone[index + 1];

                    index++;
                }
                clone[index] = null;
                participantArray[currentPosition].setCourseArray(clone);
                participantArray[currentPosition].setCourseArrayIndex(index);

                JOptionPane.showMessageDialog(null, displayParticipant());

            } else {
                JOptionPane.showMessageDialog(null, "There are no participants to remove from a course");
                menuChoice = getMenuOption();
            }
        }
    }

}//class end