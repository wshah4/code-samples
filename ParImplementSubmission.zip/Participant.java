import javax.swing.*;
/*
This body of code is used to create object instances in the Participant class.
When an object is instantiated this class will set all the default values,
and provide methods to change or see the values of instances.
*/
public class Participant{
   
   //class variables
   private String name;
   private int age;
   private String gender;
   private String cell;
   private String email;
   private final int maxCourses = 3;
   private Course[] courseArray = new Course[maxCourses];
   private int courseArrayIndex = 0;
   private int totalDue;
  // private int fee;

   //constructors
   public Participant(){
   
   }

   public Participant(String name, int age, String gender, String cell, String email){
      setName(name);
      setAge(age);
      setGender(gender);
      setCell(cell);
      setEmail(email);
   }

   //acc/mut
   public void setName(String name){
      if(name.length() <= 0){
         throw new IllegalArgumentException("Invalid name entered");
      }else{
         this.name = name;
      }
   }
   
   public String getName(){
      return name;
   }
   
   public void setAge(int age){
      if(age < 35 || age > 50){
         throw new IllegalArgumentException("Age entered is Invalid");
      }
      this.age = age;
   }
   
   public int getAge(){
      return age;
   }
   
   public void setGender(String gender){
      if(gender.length() <= 0){
         throw new IllegalArgumentException("Gender entered is invalid");
      }else{
         this.gender = gender;
      }
   }
   
   public String getGender(){
      return gender;
   }
   
   //the setter  will provide the program with exceptions which will be thrown if the user input an invalid input
   public void setCell(String cell){
      boolean flag = false;
      //here the code will ensure the number is 12 characters including numbers and dots
      if(cell.length() <= 0 || cell.length() != 12){
         throw new IllegalArgumentException("cell phone number is invalid");
      }else{
         int i = 0;
         char d = '.';
         //here the code will look for periods at the index 3 and 7 to make sure they are periods and not digits
         for(i = 0; i < cell.length(); i ++){
               if(i==3 || i==7){
                  char c = cell.charAt(i);
                  if(c==d){
                     flag = true;
                  }else{
                     throw new IllegalArgumentException("Cell number does not meet format requirments.");
                  }
               }else{
               //here the code will make sure the rest of the characters in the number are digits
                  char c1 = cell.charAt(i);
                  if(Character.isDigit(c1)){
                     flag = true;
                  }else{
                     throw new IllegalArgumentException("Cell number does not meet format requirments.");
                  }
               }
           }
        this.cell = cell;
      }
   }
   
   public String getCell(){
      return cell;
   }
   
   //the email setter provides with detailed error checking
   public void setEmail(String email){
      int i = 0;
      int atCounter = 0;
      int atIndex = 0;
      int periodIndex = 0;
      char d = '@';
      char p = '.';
      char u = '_';
      boolean atSymbol = true;
      boolean nonChar = false;
      
      //this block of code will find the @ symbol, and validate the remaining characters to be valid inputss
      for(i=0; i < email.length(); i++){
         char c = email.charAt(i);
            if(c == d){
               atCounter ++;
               atIndex = i;               
               }
            if(c == p){
               periodIndex = i;               
               }
            if((c==d || c==p || c==u) || (Character.isDigit(c)) || (Character.isLetter(c)) ){
               nonChar = true;
            }else{
               nonChar = false;
               return;
            }
             
      }
      // here the code will make sure only one @ symbol is used per email
      if(atCounter != 1 || periodIndex == 0 || periodIndex < atIndex){
         atSymbol = false;
      }else{
         String e3 = email.substring(periodIndex+1);
         int letterCounter = 0;
            for(i = 0; i < e3.length(); i++){
               char c = e3.charAt(i);
                  if(c == p){
                     atSymbol = false;
                  }
                  letterCounter = i;
            }
            if(letterCounter < 1){
               JOptionPane.showMessageDialog(null, "There must be at least 2 letters after the last '.' ");
               nonChar = false;
            }            
      }
      
      
      if(atSymbol == false || nonChar == false){
         throw new IllegalArgumentException("Email does not meet email format requirments");
      }else{
         this.email = email;
      }
   }
   
   public String getEmail(){
      return email;
   }
   
   public void setCourseArray(Course[] courseArray){
      this.courseArray = courseArray;   
      }
   
   public Course[] getCourseArray(){
      Course[] newCourseArray = new Course[courseArray.length];
      for(int i = 0; i <newCourseArray.length; i++){
         newCourseArray[i] = courseArray[i];
      }
      return newCourseArray;
   }
   
   
   public void setCourseArrayIndex(int courseArrayIndex){
      this.courseArrayIndex = courseArrayIndex;
   }
   
   public int getCourseArrayIndex(){
      return courseArrayIndex;
   }
      
   public void setTotalDue(int totalDue){
      this.totalDue = totalDue;
   }
   
   public int getTotalDue(){
      return totalDue;
   }
   
   //the toString method will gather all values and print out a detailed report
  public String toString(){
      int fee = 0;
      Course clone = new Course();
      String courseEnrollment = "";
      for(int i = 0; i < courseArray.length; i++){
         if(!(courseArray[i]==(null))){
            courseEnrollment = courseEnrollment + "\n" + courseArray[i].getCourse();
            fee = fee + courseArray[i].getPrice();
         }
      }
      this.setTotalDue(fee);
      String report ="* Participant type: " + getClass() 
                              + "\n Participant Name: " + getName()
                              + "   Participant Age: "+ getAge()
                              + "   Participant Gender: "+ getGender()
                              + "\n Participant Cell: "+ getCell()
                              + "   Participant Email: "+ getEmail()
                              + "   Participant Course Enrollment: "+ courseEnrollment 
                              + "\n Total Due: " + getTotalDue();
         return report;
   }
  
}//class end