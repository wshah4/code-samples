import javax.swing.*;
/*
This body of code is used to create object instances in the PartneredParticipant class.
When an object is instantiated this class will set all the default values,
and provide methods to change or see the values of instances. This class inherits methods and variables from its parent
class (Participant).
*/
public class PartneredParticipant extends Participant{

//class variables
private String orgName;
private int discount;
public double totalDue;
   
   //constructors
   PartneredParticipant(){
      super();
   }

   PartneredParticipant(String name, int age, String gender, String cell, String email, String orgName, int discount){
      this.setName(name);
      this.setAge(age);
      this.setGender(gender);
      this.setCell(cell);
      this.setEmail(email);
      setOrgName(orgName);
      setDiscount(discount);    
   }

//acc/mut
   
   public void setOrgName(String orgName){
      if(orgName.length() <= 0){
         throw new IllegalArgumentException("Invalid orginization name entered");
      }else{
         this.orgName = orgName;      
      }
   }
   
   public String getOrgName(){
      return orgName;
   }
   
   public void setDiscount(int discount){
      if(discount < 0 || discount > 99){
         throw new IllegalArgumentException("Discount entered is invalid");
      }else{
         this.discount = discount;
      }
   }
   
   public int getDiscount(){
      return discount;
   }
   
   public void setTotalDue(){
      double disTotal = super.getTotalDue() * this.getDiscount()/100;
      this.totalDue = disTotal;
      
   }
   
   public double getDisTotalDue(){
      return this.totalDue;
   }

   public String toString(){
   
      String report = super.toString();
      double x = super.getTotalDue()*discount/100;
      x = super.getTotalDue() - x;
      report += "\nTotal Due = $"+ x + "   Discount = $" + discount;
      return report;
   }
   
   
}//class end