import javax.swing.*;
/*
This body of code is used to create object instances in the Course class.
When an object is instantiated this class will set all the default values,
and provide methods to change or see the values of instances.
*/
public class Course{

//class variables
private String course;
private int price;

//constructors

Course(){

}

Course(String courseName){
   setCourse(courseName);
   setPrice(100);
}

Course(String courseName, int price){
   setCourse(courseName);
   setPrice(price);
}
//acc/mut

   public void setCourse(String course){
      this.course = course;
   }
   
   public String getCourse(){
      return course;
   }

   public void setPrice(int price){
      this.price = price;
   }
   
   public int getPrice(){
     return price; 
   }

}//class end